function generateTableFor(number) {
    let result = '<p>Multiplication Table using <strong>for loop</strong>:</p>';
    for (let i = 1; i <= 10; i++) {
        result += `${number} x ${i} = ${number * i}<br>`;
    }
    return result;
}

function generateTableWhile(number) {
    let result = '<p>Multiplication Table using <strong>while loop</strong>:</p>';
    let i = 1;
    while (i <= 10) {
        result += `${number} x ${i} = ${number * i}<br>`;
        i++;
    }
    return result;
}

function generateTableDoWhile(number) {
    let result = '<p>Multiplication Table using <strong>do-while loop</strong>:</p>';
    let i = 1;
    do {
        result += `${number} x ${i} = ${number * i}<br>`;
        i++;
    } while (i <= 10);
    return result;
}

function generateAllTables() {
    const numberInput = document.getElementById('number-input');
    const number = numberInput.value;

    if (number === '') {
        alert('Please enter a number');
        return;
    }

    let resultDiv = document.getElementById('result');

    resultDiv.innerHTML = '';

    let forLoopResult = generateTableFor(number);
    let whileLoopResult = generateTableWhile(number);
    let doWhileLoopResult = generateTableDoWhile(number);

    resultDiv.innerHTML = forLoopResult + '<br>' + whileLoopResult + '<br>' + doWhileLoopResult;

    numberInput.value = '';
}

// Additional functions to handle button clicks for individual loop types
function generateTableForButton() {
    const numberInput = document.getElementById('number-input');
    const number = numberInput.value;

    if (number === '') {
        alert('Please enter a number');
        return;
    }

    let resultDiv = document.getElementById('result');
    resultDiv.innerHTML = generateTableFor(number);
}

function generateTableWhileButton() {
    const numberInput = document.getElementById('number-input');
    const number = numberInput.value;

    if (number === '') {
        alert('Please enter a number');
        return;
    }

    let resultDiv = document.getElementById('result');
    resultDiv.innerHTML = generateTableWhile(number);
}

function generateTableDoWhileButton() {
    const numberInput = document.getElementById('number-input');
    const number = numberInput.value;

    if (number === '') {
        alert('Please enter a number');
        return;
    }

    let resultDiv = document.getElementById('result');
    resultDiv.innerHTML = generateTableDoWhile(number);
}
