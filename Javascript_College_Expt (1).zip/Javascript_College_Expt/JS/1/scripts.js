function areaofRectangle() {
    const length = parseFloat(document.getElementById("len").value);
    const breadth = parseFloat(document.getElementById("bre").value);
    if (isNaN(length) || isNaN(breadth) || breadth <= 0 || length <= 0) {
        alert("Please enter correct values.");
    } else {
        const area = length * breadth;
        document.getElementById("result").textContent =
            "The area of the rectangle is: " + area;
    }
}
function areaofCircle() {
    const radius = parseInt(document.getElementById("rad").value);
    if (isNaN(radius) || radius <= 0) {
        alert("Please enter valid Radius");
    } else {
        const areaCircle = 3.14 * radius * radius;
        document.getElementById("result2").textContent =
            "The area of Circle is: " + areaCircle;
    }
}
function areaofTriangle() {
    const s1 = parseInt(document.getElementById("side1").value);
    const s2 = parseInt(document.getElementById("side2").value);
    const s3 = parseInt(document.getElementById("side3").value);
    if (isNaN(s1) || isNaN(s2) || isNaN(s3)) {
        alert("All fields are required.");
    }
    else if (s1 <= 0 || s2 <= 0 || s3 <= 0 || (s1 + s2) <= s3 || s2 + s3 <= s1 || s3 + s1 <= s2) {
        alert("All fields must be valid.");
    } else {
        const s = (s1 + s2 + s3) / 2;
        const area = Math.sqrt(s * (s - s1) * (s - s2) * (s - s3));
        document.getElementById("triangleResult").textContent =
            "The area of the triangle is: " + area.toFixed(2);
    }
} 
