function validateForm() {
    const name = document.getElementById('name').value;
    const address = document.getElementById('address').value;
    const city = document.getElementById('city').value;
    const state = document.getElementById('state').value;
    const gender = document.getElementById('gender').value;
    const mobile = document.getElementById('mobile').value;
    const email = document.getElementById('email').value;

    const namePattern = /^[A-Za-z\s]+$/;
    const mobilePattern = /^[0-9]{10}$/;
    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    let message = '';

    if (!name || !name.match(namePattern)) {
        message += 'Please enter a valid name.\n';
    }

    if (!address) {
        message += 'Address is required.\n';
    }

    if (!city) {
        message += 'City is required.\n';
    }

    if (!state) {
        message += 'State is required.\n';
    }

    if (!gender) {
        message += 'Please select a gender.\n';
    }

    if (!mobile || !mobile.match(mobilePattern)) {
        message += 'Please enter a valid 10-digit mobile number.\n';
    }

    if (!email || !email.match(emailPattern)) {
        message += 'Please enter a valid email address.\n';
    }

    if (message) {
        alert('Errors:\n' + message);
    } else {
        document.getElementById('result').innerText = 'Congratulations! Form submitted successfully.';
    }
}
