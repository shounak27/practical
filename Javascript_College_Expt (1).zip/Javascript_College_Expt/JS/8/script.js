let colors = ['#66ccff', '#3422cc'];
let currentColorIndex = 0;

document.getElementById('hoverBox').addEventListener('mouseover', function () {
    document.body.style.backgroundColor = '#4522';
});

document.getElementById('hoverBox').addEventListener('mouseout', function () {
    document.body.style.backgroundColor = '';
});

document.getElementById('focusInput').addEventListener('focus', function () {
    document.body.style.backgroundColor = '#00453';
});

document.getElementById('focusInput').addEventListener('blur', function () {
    document.body.style.backgroundColor = '';
});

document.getElementById('focusInput').addEventListener('click', function () {
    currentColorIndex = (currentColorIndex + 1) % colors.length;
    document.body.style.backgroundColor = colors[currentColorIndex];
});
