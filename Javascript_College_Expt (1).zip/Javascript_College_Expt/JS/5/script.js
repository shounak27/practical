function startCountdown() {
    const dateInput = document.getElementById('dateInput').value;
    const hours = document.getElementById('hours').value || 0;
    const minutes = document.getElementById('minutes').value || 0;
    const seconds = document.getElementById('seconds').value || 0;
    const countdownElement = document.getElementById('timeRemaining');
    const messageElement = document.getElementById('message');

    clearInterval(countdownElement.countdownInterval);
    countdownElement.textContent = '';

    const targetDate = new Date(dateInput);
    targetDate.setHours(hours);
    targetDate.setMinutes(minutes);
    targetDate.setSeconds(seconds);

    if (!dateInput || targetDate.getTime() <= Date.now()) {
        messageElement.textContent = 'Please enter a valid future date and time.';
        countdownElement.textContent = '';
        return;
    }

    messageElement.textContent = '';

    countdownElement.countdownInterval = setInterval(() => {
        const now = new Date().getTime();
        const distance = targetDate.getTime() - now;

        if (distance <= 0) {
            clearInterval(countdownElement.countdownInterval);
            countdownElement.textContent = 'Countdown finished!';
            return;
        }

        const days = Math.floor(distance / (1000 * 60 * 60 * 24));
        const hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        const minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
        const seconds = Math.floor((distance % (1000 * 60)) / 1000);

        countdownElement.textContent = `${days}d ${hours}h ${minutes}m ${seconds}s`;
    }, 1000);
}
