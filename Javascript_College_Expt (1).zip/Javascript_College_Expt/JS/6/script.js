let array = [];

function createArrayInputs() {
    const arrayLength = parseInt(document.getElementById("arrayLength").value);
    const arrayInputsDiv = document.getElementById("arrayInputs");
    arrayInputsDiv.innerHTML = '';

    for (let i = 0; i < arrayLength; i++) {
        const input = document.createElement('input');
        input.type = 'text';
        input.id = `arrayElement${i}`;
        input.placeholder = `Enter value ${i + 1}`;
        arrayInputsDiv.appendChild(input);
        arrayInputsDiv.appendChild(document.createElement('br'));
    }
}

function performOperations() {
    const arrayLength = parseInt(document.getElementById("arrayLength").value);
    let deleteElement = document.getElementById("deleteElement").value;
    let checkElement = document.getElementById("checkElement").value;

    array = [];
    for (let i = 0; i < arrayLength; i++) {
        let value = document.getElementById(`arrayElement${i}`).value;
        array.push(value);
    }

    document.getElementById("originalArray").innerText = "Original Array: " + array.join(", ");

    array = array.filter(item => item !== deleteElement);
    document.getElementById("modifiedArray").innerText = "Array after Deletion: " + array.join(", ");

    let contains = array.includes(checkElement);
    document.getElementById("checkResult").innerText = "Contains " + checkElement + ": " + contains;
}

function emptyArray() {
    array = [];
    document.getElementById("arrayStatus").innerText = "Array is now empty.";
    document.getElementById("originalArray").innerText = "";
    document.getElementById("modifiedArray").innerText = "";
    document.getElementById("checkResult").innerText = "";
    document.getElementById("arrayInputs").innerHTML = "";
    document.getElementById("arrayLength").value = "";
}
